echo "start item_tfidf task"

#unset PYSPARK_DRIVER_PYTHON

spark-submit /root/bigdata-tasks/pyfiles/item_tfidf.py
